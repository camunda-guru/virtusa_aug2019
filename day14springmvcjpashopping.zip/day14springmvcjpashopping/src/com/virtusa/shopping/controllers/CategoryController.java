package com.virtusa.shopping.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CategoryController {

	@GetMapping("/addcategory")
	public String addCategory()
	{
		return "addcategory";
	}
}
