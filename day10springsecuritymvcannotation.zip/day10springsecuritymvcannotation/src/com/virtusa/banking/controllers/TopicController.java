package com.virtusa.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TopicController {

	@GetMapping("/positive")
	public String home(Model model)
	{
        model.addAttribute("message", "Turning Negatives Into Positives");
        return "positive";
	}
	
}
